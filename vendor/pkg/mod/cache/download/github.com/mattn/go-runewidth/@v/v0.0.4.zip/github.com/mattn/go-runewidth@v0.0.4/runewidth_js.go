// +build js
// +build !appengine

package runewidth

func IsEastAsian() bool {
	// TODO: Implement this for the web. Detect east asian in a compatible way, and return true.
	return false
}
