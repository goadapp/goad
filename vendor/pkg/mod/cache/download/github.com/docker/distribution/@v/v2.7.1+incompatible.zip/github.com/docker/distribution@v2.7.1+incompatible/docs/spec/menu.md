---
title: "Reference"
description: "Explains registry JSON objects"
keywords: registry, service, images, repository, json
type: "menu"
identifier: "smn_registry_ref"
---
