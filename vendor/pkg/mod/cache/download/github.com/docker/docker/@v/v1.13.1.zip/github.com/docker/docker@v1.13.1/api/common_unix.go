// +build !windows

package api

// MinVersion represents Minimum REST API version supported
const MinVersion string = "1.12"
