package main

import "github.com/goadapp/goad/cli"

func main() {
	cli.Run()
}
